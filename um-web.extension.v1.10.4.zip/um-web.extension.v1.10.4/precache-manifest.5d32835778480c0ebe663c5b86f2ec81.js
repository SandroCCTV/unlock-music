self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "efa56531e578a75f4bb1",
    "url": "css/app.3f25f0c2.css"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "1d89f9ca50921f4a03571539d29c4a1f",
    "url": "index.html"
  },
  {
    "revision": "e2222e3291fee382d79474dc72cbbc3c",
    "url": "js/0.d7900b20.worker.js"
  },
  {
    "revision": "efa56531e578a75f4bb1",
    "url": "js/app.77cfd520.js"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "js/chunk-vendors.5db7ca01.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);